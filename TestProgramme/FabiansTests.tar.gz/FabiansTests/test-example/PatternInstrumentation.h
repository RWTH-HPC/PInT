#pragma once

#include <string>


namespace PatternInstrumentation 
{
	void Pattern_Begin (std::string Pattern)
	{
	}

	void Pattern_End (std::string Pattern)
	{
	}
}
