#pragma once

void external_function();
