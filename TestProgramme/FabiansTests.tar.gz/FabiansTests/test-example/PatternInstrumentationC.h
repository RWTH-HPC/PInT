#pragma once

#include <stdio.h>

void PatternInstrumentation_Pattern_Begin (char* Pattern)
{
}

void PatternInstrumentation_Pattern_End (char* Pattern)
{
}
